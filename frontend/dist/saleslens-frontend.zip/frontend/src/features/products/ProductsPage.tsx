import { FeatureScaffold } from '@/features/FeatureScaffold'

export function ProductsPage() {
  return <FeatureScaffold endpoint="/products" />
}
