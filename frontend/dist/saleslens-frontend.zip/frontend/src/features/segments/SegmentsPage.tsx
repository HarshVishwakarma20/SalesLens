import { FeatureScaffold } from '@/features/FeatureScaffold'
import { SegmentMixPanel } from '@/features/overview/OverviewPanels'
import { Skeleton } from '@/components/ui/skeleton'
import { useDataset } from '@/hooks/useDataset'

export function SegmentsPage() {
  const { data } = useDataset()
  return (
    <FeatureScaffold endpoint="/segments">
      <div className="grid grid-cols-12 gap-6">
        {data ? <SegmentMixPanel segments={data.segments} total={data.customers} /> : <Skeleton className="col-span-12 h-80 rounded-2xl lg:col-span-4" />}
      </div>
    </FeatureScaffold>
  )
}
