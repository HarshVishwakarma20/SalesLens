import { FeatureScaffold } from '@/features/FeatureScaffold'

export function SimulatorPage() {
  return <FeatureScaffold endpoint="/simulator" />
}
