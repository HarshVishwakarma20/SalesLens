import { FeatureScaffold } from '@/features/FeatureScaffold'

export function MlLabPage() {
  return <FeatureScaffold endpoint="/ml-lab" />
}
