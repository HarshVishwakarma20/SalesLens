import { FeatureScaffold } from '@/features/FeatureScaffold'

export function CohortsPage() {
  return <FeatureScaffold endpoint="/cohorts" />
}
