import { FeatureScaffold } from '@/features/FeatureScaffold'

export function PipelinePage() {
  return <FeatureScaffold endpoint="/pipeline" />
}
