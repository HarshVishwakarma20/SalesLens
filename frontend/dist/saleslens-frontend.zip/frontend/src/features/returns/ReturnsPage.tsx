import { FeatureScaffold } from '@/features/FeatureScaffold'
import { LeakagePanel, MonthlySalesPanel } from '@/features/overview/OverviewPanels'
import { Skeleton } from '@/components/ui/skeleton'
import { useDataset } from '@/hooks/useDataset'

export function ReturnsPage() {
  const { data } = useDataset()
  return (
    <FeatureScaffold endpoint="/returns">
      {data ? (
        <div className="grid grid-cols-12 gap-6 [&>section]:lg:col-span-12">
          <MonthlySalesPanel data={data.monthly} />
          <LeakagePanel leakage={data.leakage} />
        </div>
      ) : (
        <Skeleton className="h-80 rounded-2xl" />
      )}
    </FeatureScaffold>
  )
}
