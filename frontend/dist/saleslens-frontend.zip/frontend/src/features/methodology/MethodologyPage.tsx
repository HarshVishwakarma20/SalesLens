import { FeatureScaffold } from '@/features/FeatureScaffold'

export function MethodologyPage() {
  return <FeatureScaffold endpoint="/methodology" />
}
