import { FeatureScaffold } from '@/features/FeatureScaffold'

export function JourneyPage() {
  return <FeatureScaffold endpoint="/journey" />
}
