import { FeatureScaffold } from '@/features/FeatureScaffold'
import { Card, CardHeader } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { DailyAnomalyChart } from '@/components/charts/DailyAnomalyChart'
import { useDataset } from '@/hooks/useDataset'

export function AnomaliesPage() {
  const { data } = useDataset()
  const flagged = data?.daily.filter((d) => d.flagged).length ?? 0

  return (
    <FeatureScaffold endpoint="/anomalies">
      {data ? (
        <Card className="p-6">
          <CardHeader
            className="mb-4"
            title="Daily net sales"
            description="Days beyond 2 standard deviations from the rolling mean are flagged"
            actions={<span className="num-tabular font-mono text-xs text-negative">{flagged} flagged days</span>}
          />
          <DailyAnomalyChart data={data.daily} />
        </Card>
      ) : (
        <Skeleton className="h-80 rounded-2xl" />
      )}
    </FeatureScaffold>
  )
}
