import { FeatureScaffold } from '@/features/FeatureScaffold'
import { RiskCustomersPanel } from '@/features/overview/OverviewPanels'
import { Skeleton } from '@/components/ui/skeleton'
import { useDataset } from '@/hooks/useDataset'

export function RiskPage() {
  const { data } = useDataset()
  return (
    <FeatureScaffold endpoint="/risk">
      <div className="grid grid-cols-12 gap-6 [&>section]:lg:col-span-12">
        {data ? <RiskCustomersPanel customers={data.riskCustomers} /> : <Skeleton className="col-span-12 h-80 rounded-2xl" />}
      </div>
    </FeatureScaffold>
  )
}
