export type SegmentName = 'Champion' | 'Loyal' | 'Promising' | 'New' | 'At-Risk' | 'Lost'

export type RiskBand = 'Low' | 'Medium' | 'High' | 'Critical'

export interface Segment {
  name: SegmentName
  count: number
  share: number
}

export interface MonthlyPoint {
  month: string
  sales: number
  returns: number
  returnRate: number
  partial?: boolean
}

export interface DailyPoint {
  date: string
  sales: number
  flagged: boolean
}

export interface RiskCustomer {
  id: string
  segment: SegmentName
  band: RiskBand
  score: number
}

export interface DatasetSummary {
  id: string
  name: string
  uploaded: string
  rows: number
  status: 'Processed' | 'Archived'
  primary?: boolean
}

export interface Kpi {
  key: string
  label: string
  value: string
  prefix?: string
  tooltip: string
  badge?: string
  delta?: string
  note?: string
  trend: number[]
  tone: 'accent' | 'accent-2' | 'warning' | 'positive'
}

export interface Dataset {
  id: string
  name: string
  customers: number
  rows: number
  dateRange: { from: string; to: string }
  kpis: Kpi[]
  monthly: MonthlyPoint[]
  segments: Segment[]
  daily: DailyPoint[]
  riskCustomers: RiskCustomer[]
  leakage: { gross: number; returns: number; net: number }
}

export type UploadMode = 'cleaned' | 'raw'

export type StepStatus = 'waiting' | 'running' | 'done'

export interface JobStep {
  label: string
  status: StepStatus
}
