import type { DailyPoint, Dataset, DatasetSummary, MonthlyPoint } from './types'

const MONTHS = ['Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec*']
const SALES_K = [510, 490, 450, 650, 560, 620, 640, 640, 660, 900, 950, 1330, 330]
const RETURNS_K = [28, 26, 24, 35, 30, 33, 35, 34, 36, 48, 52, 72, 18]

const monthly: MonthlyPoint[] = MONTHS.map((month, i) => ({
  month,
  sales: SALES_K[i],
  returns: RETURNS_K[i],
  returnRate: Number(((RETURNS_K[i] / SALES_K[i]) * 100).toFixed(2)),
  partial: i === MONTHS.length - 1,
}))

function buildDailySeries(): DailyPoint[] {
  const start = new Date(Date.UTC(2010, 11, 1))
  const flaggedIdx = new Set([15, 32, 39, 95, 100, 128, 141, 167, 189, 214, 231, 248, 262, 277, 289, 298])
  let seed = 42
  const rand = () => {
    seed = (seed * 16807) % 2147483647
    return seed / 2147483647
  }
  return Array.from({ length: 305 }, (_, i) => {
    const date = new Date(start)
    date.setUTCDate(start.getUTCDate() + Math.round(i * 1.2))
    const seasonal = 18000 + i * 75 + Math.sin(i / 9) * 4200
    const holiday = i > 250 && i < 290 ? 14000 : 0
    const flagged = flaggedIdx.has(i)
    const spike = flagged ? (i % 3 === 0 ? -0.55 : 1.15) * seasonal : 0
    const sales = Math.max(4000, seasonal + holiday + (rand() - 0.5) * 6000 + spike)
    return { date: date.toISOString().slice(0, 10), sales: Math.round(sales), flagged }
  })
}

export const DEMO_DATASET: Dataset = {
  id: 'uci-demo',
  name: 'UCI Online Retail - Demo',
  customers: 4334,
  rows: 399659,
  dateRange: { from: '01 Dec 2010', to: '09 Dec 2011' },
  kpis: [
    {
      key: 'active',
      label: 'Active Customers',
      value: '3,362',
      tooltip: 'Customers whose segment is not Lost',
      delta: '+4.8%',
      trend: [3, 2, 4, 5, 3, 6, 7, 6, 8, 9, 8, 11],
      tone: 'accent',
    },
    {
      key: 'repeat',
      label: 'Repeat Rate',
      value: '65.27%',
      tooltip: 'Customers with 2+ orders',
      delta: '+1.2%',
      trend: [4, 5, 3, 6, 7, 6, 8, 7, 9, 8, 10, 10],
      tone: 'accent',
    },
    {
      key: 'churn',
      label: 'Churn Rate',
      value: '88.52%',
      badge: 'Indicative',
      tooltip: 'Based on one partial calendar month',
      note: 'Lost segment: 22.4%',
      trend: [9, 8, 10, 7, 8, 6, 7, 5, 4, 3, 4, 2],
      tone: 'warning',
    },
    {
      key: 'retention',
      label: 'Rev. Retention',
      value: '29.79%',
      tooltip: 'Average cohort revenue after month 0',
      note: 'Dec 10 - Dec 11',
      trend: [1, 8, 7, 6, 7, 5, 6, 7, 6, 8, 7, 8],
      tone: 'accent-2',
    },
    {
      key: 'net',
      label: 'Net Revenue',
      value: '8.27M',
      prefix: '£',
      tooltip: 'GBP 8,265,476.93',
      delta: '+14.2% YoY',
      trend: [2, 3, 1, 5, 4, 6, 7, 7, 8, 10, 11, 11],
      tone: 'positive',
    },
  ],
  monthly,
  segments: [
    { name: 'Champion', count: 897, share: 0.207 },
    { name: 'Loyal', count: 390, share: 0.09 },
    { name: 'Promising', count: 1078, share: 0.248 },
    { name: 'New', count: 234, share: 0.054 },
    { name: 'At-Risk', count: 763, share: 0.176 },
    { name: 'Lost', count: 972, share: 0.224 },
  ],
  daily: buildDailySeries(),
  riskCustomers: [
    { id: '13533', segment: 'At-Risk', band: 'Critical', score: 66.0 },
    { id: '15749', segment: 'At-Risk', band: 'Critical', score: 65.5 },
    { id: '18268', segment: 'Lost', band: 'High', score: 63.5 },
    { id: '15026', segment: 'At-Risk', band: 'High', score: 62.0 },
    { id: '12527', segment: 'At-Risk', band: 'High', score: 62.0 },
    { id: '13672', segment: 'Lost', band: 'High', score: 61.5 },
    { id: '16581', segment: 'Promising', band: 'High', score: 61.3 },
    { id: '14669', segment: 'At-Risk', band: 'High', score: 60.0 },
  ],
  leakage: { gross: 8_736_000, returns: 470_523, net: 8_265_476 },
}

export const RECENT_DATASETS: DatasetSummary[] = [
  { id: 'uci-demo', name: 'UCI Online Retail - Demo (Standard)', uploaded: 'Today, 09:41 AM', rows: 399659, status: 'Processed', primary: true },
  { id: 'uk-q3', name: 'UK Retail Store Q3 Export', uploaded: '18 Nov 2024', rows: 128400, status: 'Processed' },
  { id: 'fashion-2023', name: 'E-Commerce Fashion 2023 Cohort', uploaded: '02 Oct 2024', rows: 84912, status: 'Archived' },
]

export const CLEANED_COLUMNS = ['CustomerID', 'InvoiceNo', 'InvoiceDate', 'StockCode', 'NetRevenue']
export const RAW_COLUMNS = ['InvoiceNo', 'StockCode', 'Description', 'Quantity', 'InvoiceDate', 'UnitPrice', 'CustomerID', 'Country']

export const ANALYSIS_STEPS = ['Load', 'Validate', 'Customer Journey', 'RFM', 'Cohorts', 'Returns', 'Products', 'Anomalies', 'Risk Score', 'KPIs', 'Done']

export const CLEANING_STEPS = [
  'Read file',
  'Check columns',
  'Standardise types',
  'Remove duplicates',
  'Remove missing CustomerID',
  'Remove missing fields',
  'Remove zero quantity',
  'Remove negative price',
  'Remove non-product records',
  'Classify sales vs returns',
  'Compute values',
  'Save cleaned data',
]
